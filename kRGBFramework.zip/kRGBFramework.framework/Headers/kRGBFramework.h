//
//  kRGBFramework.h
//  kRGBFramework
//
//  Created by KOi on 9/20/2560 BE.
//  Copyright © 2560 KOi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for kRGBFramework.
FOUNDATION_EXPORT double kRGBFrameworkVersionNumber;

//! Project version string for kRGBFramework.
FOUNDATION_EXPORT const unsigned char kRGBFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <kRGBFramework/PublicHeader.h>


